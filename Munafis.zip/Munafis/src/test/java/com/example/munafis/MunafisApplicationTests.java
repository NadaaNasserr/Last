package com.example.munafis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MunafisApplicationTests {

    @Test
    void contextLoads() {
    }

}
